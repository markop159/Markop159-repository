# plugin.video.rtvslo
Audio / video plugin (add-on) for Kodi. It plays audio and video podcasts made by RTV Slovenia.

06.06.2016 -> version 2.0.4 (added support for "ava_archive03" media)
