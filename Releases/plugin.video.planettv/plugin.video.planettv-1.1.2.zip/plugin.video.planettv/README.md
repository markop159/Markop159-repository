# plugin.video.planettv

## What it is ##

Video plugin (add-on) for Kodi. It plays video podcasts from archive of Planet TV commercial Slovenian TV.

## Why ##

To learn new things

## Changelog ##

Version 1.0.0 (First release)
