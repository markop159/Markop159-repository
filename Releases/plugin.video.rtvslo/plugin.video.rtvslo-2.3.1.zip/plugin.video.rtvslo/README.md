# plugin.video.rtvslo

## What it is ##

Audio / video plugin (add-on) for Kodi. It plays audio and video podcasts from archive of RTV Slovenia national television.

## Why ##

To learn new things

## Changelog ##

06.06.2016 -> version 2.0.4 (added support for "ava_archive03" media)

## Credits ##

[@ro-le](https://github.com/ro-le) for his work on this plugin
